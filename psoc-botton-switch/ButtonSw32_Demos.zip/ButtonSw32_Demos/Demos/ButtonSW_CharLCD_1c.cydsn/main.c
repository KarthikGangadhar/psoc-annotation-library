/* ============================================================================
 * File Name: ButtonSw_CharLCD_1c
 *
 * Description:
 *   Scrollable menu example using 2x16 character LCD and control buttons.
 *   Project shows use of custom component ButtonSw32 for switch debouncing.
 *
 *   Cypress stock CharLCD component is used to interface LCD to PSoC. The switch
 *   buttons (Up, Down and Enter) allow for vertical scrolling of the menu and
 *   modifying parameters values, which can be of integer, float or enumerated
 *   range types. Pressing the Enter button enters (exits) the edit mode. 
 *
 *   A press on the Up/Down button increments/decrements parameter value
 *   by a predefined step.
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/


#include <project.h>
#include <Menu.h>
#include <CLCD.h>

#define BlinkLED1(); {Pin_LED1_Write(1); CyDelayUs(130); Pin_LED1_Write(0);} // blink LED indicator

#define BTN_UP 1u // Up
#define BTN_DN 2u // Down
#define BTN_EN 4u // Enter

#define UP 1
#define DN 0 


//============================================
// Global variables
//============================================
const char * words [] = { "one", "two", "three" }; // define strings for _enum type



void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
   
      
    //setup menu->
    strcpy( Menu[0].name, "FREQ" );
    Menu[0].type=_float; //float
    Menu[0].value=1000;
    Menu[0].min=990;
    Menu[0].max=1010;
    Menu[0].step=0.1;
    Menu[0].bounds=1;
    
    strcpy( Menu[1].name, "PHSE" );
    Menu[1].type=_int;  // int
    Menu[1].value=8;
    Menu[1].min=-128;
    Menu[1].max=127;
    Menu[1].step=8;
    Menu[1].bounds=1;
    
    strcpy( Menu[2].name, "AMPL" );
    Menu[2].type=_int;  // int
    Menu[2].value=100;
    Menu[2].min=0;
    Menu[2].max=255;
    Menu[2].step=5;
    Menu[2].bounds=1;

    strcpy( Menu[3].name, "SENS" );
    Menu[3].type=_enum; // enum
    Menu[3].value=0;
    Menu[3].min=0;
    Menu[3].max=2;
    Menu[3].step=1;
    Menu[3].bounds=1;
    
    SetupDecoder();         // set Decoder settings for top menu browsing (val_editing=false)
                            // Decoder class converts button UP and DOWN commands into
                            // top menu position (item_idx) and menu items value
    
    Button_1_Start();
    
    LCD_1_Start();
    LCD_1_LoadCustomFonts(LCD_1_customFonts); // cursor
    
    Repaint_LCD();          // force LCD repaint
}


int main()
{
    
    Initialize();
    
    for(;;) 
    {
        
        if (Button_1_Pressed!=0)                    // some buttons were pressed 
        {
            uint32 status = Button_1_Pressed;       // capture state
            Button_1_Pressed = 0;                   // clear flag
 
            //BlinkLED1(); // debug..


            if (status & BTN_UP)                // UP button pressed
            {    
                if (ItemValueChanged(UP)) {/* take action for item menu_idx*/ };  
            }
                
            if (status & BTN_DN)                // DOWN button pressed
            {   
                if (ItemValueChanged(DN)) {/* take action for item menu_idx*/ };  
            }
                
            if (status & BTN_EN)                // enter/exit parameter editing
            {                
                //val_editing = ~val_editing;     // toggle between top menu and value edit 
                val_editing = !val_editing;     // toggle between top menu and value edit 
                SetupDecoder();
            }    

            Refresh_LCD(); // 
        }

    }
    
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////

