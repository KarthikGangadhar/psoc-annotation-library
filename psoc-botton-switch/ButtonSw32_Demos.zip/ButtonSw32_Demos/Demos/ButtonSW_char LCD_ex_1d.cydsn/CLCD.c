/* ========================================
 * Collection of APIs for painting CharLCD
 *
 * ========================================
*/

#include <CLCD.h>
#include <Menu.h>
#include <stdio.h> // sprintf


//#define BlinkLED1(); {Pin_LED1_Write(1); CyDelayUs(130); Pin_LED1_Write(0);} // blink LED indicator


static uint8 lcd_idx = 0; // LCD top raw index 


//==============================================================================
// refresh top menu
//==============================================================================
    
void Update_Menu() 
{ 
    const uint8 NumRows = 2; // this is for 2x16 LCD:
    
    char buf[16];            //LCD output buf
    
    if (menu_idx>lcd_idx+1) lcd_idx=menu_idx-1; else
    if (menu_idx<lcd_idx) lcd_idx=menu_idx;
    

    uint8 row; 
    for (row=0; row<NumRows; row++) {
        uint8 idx = lcd_idx + row;
        if (Menu[idx].type==_int) 
            sprintf(buf, " %s  %9d", Menu[idx].name, (int) Menu[idx].value ); // int16
            //sprintf(buf, " %s  %9ld", Menu[idx].name, Menu[idx].value );  // int32
        else
        if (Menu[idx].type==_float)    
            sprintf(buf, " %s  %9.1f", Menu[idx].name, Menu[idx].value );   // float
        else
        if (Menu[idx].type==_enum)
            sprintf(buf, " %s  %9s", Menu[idx].name, words[ (uint8) Menu[idx].value ] ); // sting array
    
        
        LCD_1_Position(row, 0); LCD_1_PrintString(buf);
    }
    
    row = menu_idx - lcd_idx;
    LCD_1_Position(row, 0); LCD_1_PutChar(LCD_1_CUSTOM_0);         // index mark 
}

//==============================================================================
// redraw edited line
//==============================================================================

void Update_Value() 
{ 
    char buf[16];   //LCD output buf
    
    uint8 idx = menu_idx;
    uint8 row = menu_idx - lcd_idx;
    
    if (Menu[idx].type==_int)
        sprintf(buf, "%-9d", (int) Menu[idx].value );  // int16
        //sprintf(buf, "%-9ld", Menu[idx].value );  // int32
    else
    if (Menu[idx].type==_float) 
        sprintf(buf, "%-9.1f", Menu[idx].value );   // float
    else
    if (Menu[idx].type==_enum) 
        sprintf(buf, "%-9s",   words[ (uint8) Menu[idx].value ] ); // enum stings
        
    LCD_1_Position(row, 7); LCD_1_PrintString(buf);
    
    LCD_1_Position(row, 0); LCD_1_PutChar(LCD_1_CUSTOM_1); // index mark 
    LCD_1_Position(row, 6); LCD_1_PutChar(LCD_1_CUSTOM_0); // index mark 
}

//==============================================================================
// Force repaint LCD screen
//==============================================================================

void Repaint_LCD()
{
    //BlinkLED1(); // debug..

    if (val_editing)
        Update_Value(); // redraw edited line
    else
        Update_Menu();  // refresh top menu

}

//==============================================================================
// Repaint LCD screen if repaint flag is set
//==============================================================================

void Refresh_LCD()
{
    if (LCD_repaint_flag != 0)
    {
        LCD_repaint_flag = 0;
        Repaint_LCD(); // redraw edited line
    }    
}

/* [] END OF FILE */
