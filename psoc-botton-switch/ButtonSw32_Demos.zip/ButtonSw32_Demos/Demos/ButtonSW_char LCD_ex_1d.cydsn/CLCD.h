/* ========================================
 * Collection of APIs for painting CharLCD
 *
 * ========================================
*/

#include <project.h>

uint8 LCD_repaint_flag;         // LCD repaint flag



/***************************************
*        Function Prototypes
***************************************/

void Repaint_LCD(); // repaint LCD
void Refresh_LCD(); // repaint LCD if LCD_Repaint_flag != 0


/* [] END OF FILE */
