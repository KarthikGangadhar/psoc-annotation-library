/* ========================================
 * Collection of APIs for handling Menu items
 *
 * ========================================
*/

#include <Menu.h>
#include <CLCD.h> // LCD_repaint_flag



//uint8 menu_idx = 0; // menu selected index
//uint8 val_editing = 0; // entered parameter updating

TMenuItem TopMenu = {
    "MENU",     // name (not used)
    _int,       // type (integer)
    0,          // val (menu_idx)
    1,          // step
    0,          // min value
    MENU_LEN-1, // max value
    true        // check bounds
};


//==============================================================================
// Update Decoder settings according to Menu current state:
// a 'main menu' or 'editing parameter value'
// Decoder is a container, which keeps setting for current men
//==============================================================================

void SetupDecoder()
{    
    if (val_editing)                // enter parameter update
        Decoder = Menu[menu_idx];   // entering menu item #menu_idx
    else
    {    
        Decoder = TopMenu;          // return to top menu
        Decoder.value = menu_idx;   // restore position index
    }        
        
    LCD_repaint_flag = 1;           // LCD needs update
}


//==============================================================================
// Check if parameter value changed and response action required
// 
//==============================================================================


//==============================================================================
// Increment parameter value:
// 
//==============================================================================

void Decoder_ShiftUP()
{
    float tmp = Decoder.value + Decoder.step;
    
    if (Decoder.bounds)
    {
        if (tmp <= Decoder.max)
        {
            Decoder.value = tmp;
            LCD_repaint_flag = 1;   // item index or value changed - LCD needs update
        }    
    }
    else
    {
            Decoder.value = tmp;                        
            LCD_repaint_flag = 1;   // item index or value  changed - LCD needs update
    }
}

//==============================================================================
// Decrement parameter value:
// 
//==============================================================================

void Decoder_ShiftDN()
{
    float tmp = Decoder.value - Decoder.step;
    
    if (Decoder.bounds)
    {
        if (tmp >= Decoder.min)
        {
            Decoder.value = tmp;
            LCD_repaint_flag = 1;           // value changed - need update
        }    
    }
    else
    {
            Decoder.value = tmp;                        
            LCD_repaint_flag = 1;           // value changed - need update
    }
}


//==============================================================================
// Check if parameter value changed and response action required
// 
//==============================================================================

uint8 ItemValueChanged(uint8 dir)
{                                                                 //edit dir | UP/DN
    //if (val_editing)                // updating item value      // 1    1  |   1
    //    if (dir) Decoder_ShiftUP(); else Decoder_ShiftDN();     // 1    0  |   0  
    //else                            // browsing top menu        // 0    1  |   0 
    //    if (dir) Decoder_ShiftDN(); else Decoder_ShiftUP();     // 0    0  |   1
    
    // not work sstuck at par value limits    
    // browing menu down corresponds to increment of item_idx    
    if (val_editing ^ dir)                // updating item value
        Decoder_ShiftDN(); else Decoder_ShiftUP();

    if (val_editing)                // updating item value
        Menu[menu_idx].value = Decoder.value;   // new parameter value
    else                            // browsing top menu
        menu_idx = Decoder.value;  

    return (val_editing & LCD_repaint_flag); // value changed
}


/* [] END OF FILE */
