/* ========================================
 * Collection of APIs for handling Menu items
 *
 * ========================================
*/

#include <project.h>


    typedef enum TRange {_int, _float, _enum} range; // menu item types
    
    // todo: add explicit TMenuItem.direction
    typedef struct {
        char name[5];   // name    
        range type;     // type
        float value;    // value
        float step;     // increment step
        float min;      // min value
        float max;      // max value
        uint8 bounds;   // check bounds
    } TMenuItem;


#define MENU_LEN  (4u)          // number of menu items
    
TMenuItem Menu[MENU_LEN];       // array of parameters
TMenuItem TopMenu;              // top menu structure
TMenuItem Decoder;              // parameters container, which keeps setting for current menu item




extern const char * words [];   // container for enumerated strings
extern uint8 const CYCODE LCD_customFonts[]; // custom LCD characters

uint8 menu_idx;                 // menu selected index
uint8 val_editing;              // entered parameter updating



//============================================
// Forward declarations
//============================================
void SetupDecoder();            // set decoder to current menu state
void Decoder_ShiftUP();         // increment parameter / position up
void Decoder_ShiftDN();         // decrement parameter / position down
uint8 ItemValueChanged(uint8 dir);


/* [] END OF FILE */
