/* ============================================================================
 * File Name: ButtonSw_CharLCD_ex_1a
 *
 * Description:
 *   Scrollable menu example using 2x16 character LCD and control buttons.
 *   Project shows use of custom component ButtonSw32 for switch debouncing.
 *
 *   Cypress stock CharLCD component is used to interface LCD to PSoC. The switch
 *   buttons (Up, Down and Enter) allow for vertical scrolling of the menu and
 *   modifying parameters values, which can be of integer, float or enumerated
 *   range types. Pressing the Enter button enters (exits) the edit mode. 
 *
 *   Pressing Up/Down buttons for longer then 1 sec (long press) enters parameter
 *   fast update mode (approx. 10 steps/sec).
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/


#include <project.h>
#include <Menu.h>
#include <CLCD.h>

#define BlinkLED1(); {Pin_LED1_Write(1); CyDelayUs(130); Pin_LED1_Write(0);} // blink LED indicator

#define BTN_UP 1u // Up
#define BTN_DN 2u // Down
#define BTN_EN 4u // Enter

#define UP 1
#define DN 0 


//============================================
// Global variables
//============================================
const char * words [] = { "one", "two", "three" }; // define strings for _enum type

uint32 button_state = 0;         // keeps buttons pressed state

const    uint8 LongPeriod = 200; // clocks per long press
const    uint8 ShortPeriod= 8;   // clocks per fast update

volatile uint8 Timer_flag   = 0; // Timer semaphor flag
volatile uint8 Timer_count  = 0; // Timer counter
         uint8 Timer_enable = 0; // Timer enable status
         uint8 Timer_Period = 0; // Timer period
        

//============================================
// The interrupt handler for WDT counter 0 interrupts. 
//============================================

CY_ISR(BtnSwIsrHandler)
{  
    Button_1_CheckStatus(); // poll Button_1 swich state
    
    if (Timer_enable)       // if Timer enabled
    {
        Timer_count++; if (Timer_count > Timer_Period) {Timer_count=0; Timer_flag = 1;} // 29
    }
}


//============================================
// Forward declarations
//============================================
void Timer_Start();             // Reset and start Timer


void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
   
      
    //setup menu->
    strcpy( Menu[0].name, "FREQ" );
    Menu[0].type=_float; //float
    Menu[0].value=1000;
    Menu[0].min=990;
    Menu[0].max=1010;
    Menu[0].step=0.1;
    Menu[0].bounds=1;
    
    strcpy( Menu[1].name, "PHSE" );
    Menu[1].type=_int;  // int
    Menu[1].value=8;
    Menu[1].min=-128;
    Menu[1].max=127;
    Menu[1].step=8;
    Menu[1].bounds=1;
    
    strcpy( Menu[2].name, "AMPL" );
    Menu[2].type=_int;  // int
    Menu[2].value=100;
    Menu[2].min=0;
    Menu[2].max=255;
    Menu[2].step=5;
    Menu[2].bounds=1;

    strcpy( Menu[3].name, "SENS" );
    Menu[3].type=_enum; // enum
    Menu[3].value=0;
    Menu[3].min=0;
    Menu[3].max=2;
    Menu[3].step=1;
    Menu[3].bounds=1;
    
    SetupDecoder();         // set Decoder settings for top menu browsing (val_editing=false)
                            // Decoder class converts button UP and DOWN commands into
                            // top menu position (item_idx) and menu items value
    
    Button_1_Start();
    
    LCD_1_Start();
    LCD_1_LoadCustomFonts(LCD_1_customFonts); // cursor
    
    Repaint_LCD();          // force LCD repaint
    
    BtnSwIsr_StartEx(BtnSwIsrHandler); // Start polling interrupt
}


int main()
{
    
    Initialize();
    
    for(;;) 
    {
        
        if (Button_1_Pressed!=0)                    // some buttons were pressed 
        {
            uint32 status = Button_1_Pressed;       // capture state
            Button_1_Pressed = 0;                   // clear flag
 
            //BlinkLED1(); // debug..

            if (button_state==0)                    // no other buttons are pressed
            {
                button_state |= status;             // record pressed button
                 
                if (status & BTN_UP)                // UP button pressed
                {    
                    Timer_Start();                  // reset and start long press timer  
                    if (ItemValueChanged(UP)) {/* take action for item menu_idx*/ };  
                }
                
                if (status & BTN_DN)                // DOWN button pressed
                {   
                    Timer_Start();                  // reset and start long press time  
                    if (ItemValueChanged(DN)) {/* take action for item menu_idx*/ };  
                }
                
                if (status & BTN_EN)                // enter/exit parameter editing
                {                
                    //val_editing = ~val_editing;     // toggle between top menu and value edit 
                    val_editing = !val_editing;     // toggle between top menu and value edit 
                    SetupDecoder();
                }    

                Refresh_LCD(); // 
            }

        }
        
        if (Button_1_Released!=0)                   // some buttons were released 
        {
            uint32 status = Button_1_Released;      // capture state
            Button_1_Released = 0;                  // clear flag
 
            button_state &= ~status;                // clear button state
            Timer_enable = (button_state!=0);       // stop timer when all buttons released
        }

        
        
        if (Timer_flag)                             // long press detected
        {
            Timer_flag = 0;
            Timer_Period = ShortPeriod;             // change timer for fast update
            
            //BlinkLED1(); // debug..
            
            if (button_state & BTN_UP) {   
                if (ItemValueChanged(UP)) {/* take action for item menu_idx*/ }; 
            };   
            
            if (button_state & BTN_DN) {  
                if (ItemValueChanged(DN)) {/* take action for item menu_idx*/ }; 
            }; 
            
            Refresh_LCD();
        }


    }
    
} //main

//==============================================================================
// Reset and start long press timer
// 
//==============================================================================

void Timer_Start()
{
    Timer_count=0; Timer_enable = true; // reset timer
    Timer_Period = LongPeriod;          // long press delay
}


/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////

