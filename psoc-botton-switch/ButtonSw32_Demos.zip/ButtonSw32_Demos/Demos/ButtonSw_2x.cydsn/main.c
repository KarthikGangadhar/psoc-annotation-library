/* ============================================================================
 * Project Name: ButtonSw_2x.proj
 *
 * Description:
 *   PSoC5 example of multiple instances of the ButtonSw32 component in the project
 *   operating in the internal interrupt mode. The Debouncers are configured for
 *   buttons press event. Pressing buttons 0, 1 turns LED on, pressing buttons 2, 3
 *   turns it off. 
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/


#include <project.h>




//============================================
// Global variables
//============================================






void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    
    Button_1_Start();   
    Button_2_Start();   
}


int main()
{
    
    Initialize();
    
    
    for(;;) 
    {
        
        // turn on LED
        if (Button_1_Pressed!=0) // some buttons were pressed //
        {
            uint32 status = Button_1_Pressed;   // capture state
            Button_1_Pressed = 0;               // clear flag
 
            if (status & BTN_0) Pin_LED1_Write(1); // 
            if (status & BTN_1) Pin_LED1_Write(1);
        }
        
        // turn off LED
        if (Button_2_Pressed!=0) // some buttons were released //
        {
            uint32 status = Button_2_Pressed;   // capture state
            Button_2_Pressed = 0;               // clear flag
 
            if (status & BTN_0) Pin_LED1_Write(0); // 
            if (status & BTN_1) Pin_LED1_Write(0);
        }
        
    }
  
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////
