/* ============================================================================
 * Project Name: ButtonSw_P4_WDT.proj
 *
 * Description:
 *   PSoC4 example utilizing WDT timer for polling the pin state. ButtonSw32
 *   Debouncer is configured for external user-provided interrupt. The WDT0
 *   timer interrupt configured as ‘User provided’, and triggered by the
 *   Global Signal. Pressing buttons 0, 1 or 2 toggles the red, green or blue
 *   LED on the CY8KIT-042 Pioneer board.
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/


#include <project.h>


//#define BlinkLED1(); {Pin_LED1_Write(0); CyDelayUs(230); Pin_LED1_Write(1);} // blink LED indicator P4

//============================================
// Global variables
//============================================


//============================================
// The interrupt handler for WDT counter 0 interrupts. 
//============================================
CY_ISR(WdtIsrHandler)
{
    //WdtIsr_ClearPending(); // Clear Interrupt (not needed)
    
    #if(CY_IP_SRSSV2)
        CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER0_INT); // Clear WDT0 interrupts state
    #else
        CySysWdtClearInterrupt();
    #endif
    
    Button_1_CheckStatus(); // poll Button_1
}




void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    
    /* Enable WDT0 counter */
    #if(CY_IP_SRSSV2)
        CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK);   // WDT=PeriodicTimer
    #else
        CySysWdtEnable();
        CySysWdtUnmaskInterrupt();                  // WDT=Watchdog
    #endif  
    
    
    WdtIsr_StartEx(WdtIsrHandler); // Start ISR for pin toggle
    
    
    //Button_1_Start();    
}


int main()
{
    
    Initialize();
    
    
    for(;;) 
    {
        
        // toggle RGB LED
        if (Button_1_Pressed!=0) // some buttons were pressed //
        {
            uint32 status = Button_1_Pressed;   // capture state
            Button_1_Pressed = 0;               // clear flag
            
            
            //BlinkLED1();
            if (status & BTN_0) Pin_RED_Write(~Pin_RED_Read()); // 
            if (status & BTN_1) Pin_GRN_Write(~Pin_GRN_Read()); // 
            if (status & BTN_2) Pin_BLU_Write(~Pin_BLU_Read()); // 
        }
        
    }
  
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////
