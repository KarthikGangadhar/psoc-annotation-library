/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef CYAPICALLBACKS_H
#define CYAPICALLBACKS_H
    
    /*Define your macro callbacks here */
    /*For more information, refer to the Macro Callbacks topic in the PSoC Creator Help.*/
    
    // define WDT callback function
    #define WdtIsr_INTERRUPT_INTERRUPT_CALLBACK  
    //void wdtInterruptCallback();
    //void Button_1_CheckStatus();         // poll Button_1
    
#endif /* CYAPICALLBACKS_H */   
/* [] */
