/* ============================================================================
 * Project Name: ButtonSw_P4_WDT_callback.proj
 *
 * Description:
 *   PSoC4 example of ButtonSw32 debouncer utilizing WDT timer for polling pin
 *   state. The WDT0 timer interrupt configured as ‘Auto generated’. Debouncer
 *   is set for external interrupt, and pins state is processed using interrupt
 *   callback procedure, which automatically clears the interrupt source.
 *   Pressing the buttons 0, 1 or 2 toggles the red, green or blue LED on the
 *   CY8KIT-042 Pioneer board.
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/

#include <project.h>


//#define BlinkLED1(); {Pin_LED1_Write(0); CyDelayUs(230); Pin_LED1_Write(1);} // blink LED indicator P4

//============================================
// Global variables
//============================================


//============================================
// The interrupt handler for WDT counter 0 interrupts. 
//============================================
/*
void wdtInterruptCallback()
{
    // see cyapicallback.h for callback definition
    // no need to clear interrupt (done automatically)
    
    // CheckStaus is an __INLINE code
    Button_1_CheckStatus();         // poll Button_1
}
*/



void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    
    // no need to enable WDT0 counter (done automatically)
    
    //CySysWdtSetInterruptCallback(CY_SYS_WDT_COUNTER0,wdtInterruptCallback); // can use standard callback
    CySysWdtSetInterruptCallback(CY_SYS_WDT_COUNTER0, Button_1_CheckStatus); // single component - can call directly
    
    //Button_1_Start(); // with external interrupt Start() is unnecessary (no isr to start)   
}


int main()
{
    
    Initialize();
    
    
    for(;;) 
    {
        
        // toggle RGB LED
        if (Button_1_Pressed!=0) // some buttons were pressed //
        {
            uint32 status = Button_1_Pressed;   // capture state
            Button_1_Pressed = 0;               // clear flag
            
            
            //BlinkLED1();
            if (status & BTN_0) Pin_RED_Write(~Pin_RED_Read()); // 
            if (status & BTN_1) Pin_GRN_Write(~Pin_GRN_Read()); // 
            if (status & BTN_2) Pin_BLU_Write(~Pin_BLU_Read()); // 
        }
        
    }
  
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////
