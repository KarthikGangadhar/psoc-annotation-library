/* ============================================================================
 * Project Name: ButtonSw_P4_basic.proj
 *
 * Description:
 *    Example of ButtonSw32 debouncer operating on PSoC4 using internal interrupt.
 *  . On PSoC4 a clock can’t connect to an interrupt directly, so a TFF element
 *    is used to interface both. Switches 0, 1 and 2 are sampled at 100 Hz rate.
 *    Since TFF divides frequency by half, the clock is set to 200 Hz. 
 *    The Debouncer is configured for the buttons press event. Pressing buttons
 *    0, 1 or 2 toggles the red, green or blue LEDs. 
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/


#include <project.h>


//#define BlinkLED1(); {Pin_LED1_Write(0); CyDelayUs(230); Pin_LED1_Write(1);} // blink LED indicator P4

//============================================
// Global variables
//============================================






void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    
    Button_1_Start();    
}


int main()
{
    
    Initialize();
    
    
    for(;;) 
    {
        
        // toggle on LEDs
        if (Button_1_Pressed!=0) // some buttons were pressed //
        {
            uint32 status = Button_1_Pressed;   // capture state
            Button_1_Pressed = 0;               // clear flag
            
            
            //BlinkLED1();
            if (status & BTN_0) Pin_RED_Write(~Pin_RED_Read()); // 
            if (status & BTN_1) Pin_GRN_Write(~Pin_GRN_Read()); // 
            if (status & BTN_2) Pin_BLU_Write(~Pin_BLU_Read()); // 
        }
        

        
    }
  
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////
