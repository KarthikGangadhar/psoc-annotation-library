/* ============================================================================
 * Project Name: ButtonSw_basic.proj
 *
 * Description:
 *   PSoC5 basic example of switch debouncing using custom component ButtonSw32.
 * 
 *   The Debouncer is configured for the buttons press event and internal interrupt.
 *   All switches are sampled at 100 Hz rate. Pressing any button toggles the LED
 *   on/off.
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/


#include <project.h>




//============================================
// Global variables
//============================================






void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    
    Button_1_Start();   
}


int main()
{
    
    Initialize();
    
    
    for(;;) 
    {
        
        // turn on LED
        if (Button_1_Pressed!=0) // some buttons were pressed //
        {
            uint32 status = Button_1_Pressed;       // capture state
            Button_1_Pressed = 0;                   // clear flag
 
            if (status & BTN_0) Pin_LED1_Write(1);  // turn LED on
            if (status & BTN_1) Pin_LED1_Write(0);  // turn LED off
        }
        
        
    }
  
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////
