/* ============================================================================
 * Project Name: ButtonSw_long press_1c.proj
 *
 * Description:
 *   PSoC5 example of the button switch debouncing component ButtonSw32, to achieve
 *   a ‘long press’ effect. The component is configured for the buttons press and
 *   release events and uses xternal interrupt. The switches are sampled at
 *   100 Hz rate. A short press of a button causes corresponding LED to blink once.
 *   When long press is detected (button stays pressed for longer than 1 sec)
 *   the LED starts blinking at fast pace of 10 Hz. Here an LED blinking simulates
 *   some user-defined action, such as a parameter increment/decrement on pressing
 *   Up/Down buttons
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/

#include <project.h>
#include <stdlib.h>
#include <stdio.h>

#define BlinkLED();   {Pin_LED_Write(1);   CyDelayUs(130); Pin_LED_Write(0);} // blink LED indicator 
#define BlinkLED_1(); {Pin_LED_1_Write(1); CyDelayUs(530); Pin_LED_1_Write(0);} // blink LED indicator 
#define BlinkLED_2(); {Pin_LED_2_Write(1); CyDelayUs(530); Pin_LED_2_Write(0);} // blink LED indicator 


//============================================
// Global variables
//============================================

const uint8 LongPeriod = 100;
const uint8 ShortPeriod= 8;

volatile uint8 Timer_flag   = 0; // Timer semaphor flag
volatile uint8 Timer_count  = 0;
         uint8 Timer_enable = 0;
         uint8 Timer_Period = 0;
        
uint32 button_state = 0;

//============================================
// The interrupt handler for WDT counter 0 interrupts. 
//============================================

CY_ISR(BtnSwIsrHandler)
{  
    Button_1_CheckStatus(); // poll Button_1 
    
    if (Timer_enable) // if Timer enabled
    {
        Timer_count++; if (Timer_count > Timer_Period) {Timer_count=0; Timer_flag = 1;} // 29
    }
}

//============================================
// Forward declarations
//============================================

//void DisplayData(uint32 status); // output to terminal


void Initialize(void)
{   
    CyGlobalIntEnable; //enable global interrupts.
    Button_1_Start();   
    BtnSwIsr_StartEx(BtnSwIsrHandler); // Start ISR for pin toggle
}


int main()
{
    
    Initialize();
    
   
    for(;;) 
    {
        
        if (Button_1_Pressed!=0) // some buttons were pressed //
        {
            uint32 status = Button_1_Pressed;       // capture state
            Button_1_Pressed = 0;                   // clear flag
 
            //BlinkLED(); // debug..
            
            if (button_state==0)                    // only one button allowed at a time
            {
                button_state |= status;             // record pressed button
                Timer_count=0; Timer_enable = true; // reset timer
                Timer_Period = LongPeriod;          // long press delay
                
                if (status & BTN_0) {BlinkLED_1()};  // some action
                if (status & BTN_1) {BlinkLED_2()};  // some action
            }

                
        }
        
        if (Button_1_Released!=0) // some buttons were released //
        {
            uint32 status = Button_1_Released;      // capture state
            Button_1_Released = 0;                  // clear flag
 
            button_state &= ~status;                // clear button state
            Timer_enable = (button_state!=0);       // stop timer when all buttons released
        }
        
        if (Timer_flag) // enter long press mode
        {
            Timer_flag = 0;
            Timer_Period = ShortPeriod;               // fast blinking
            
            if (button_state & BTN_0) {BlinkLED_1()}; // some action  
            if (button_state & BTN_1) {BlinkLED_2()}; // some action
        }
        
    }
  
} //main



/// END OF PROGRAM //////////////////////////////////////////////////////////////////////////////////////
