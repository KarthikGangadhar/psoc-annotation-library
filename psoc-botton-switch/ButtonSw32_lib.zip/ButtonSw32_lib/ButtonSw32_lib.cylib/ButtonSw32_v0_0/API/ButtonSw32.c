/* ============================================================================
 * File Name: ButtonSw32.c
 *   ButtonSw32_v0.0
 *
 * Description:
 *   Implements vertical counters algorithm using polling technique.
 *   Detects button pressed and released events.
 *   Detects up to 32 buttons. 
 *
 * Credits:
 *   based on vertical counters algorithm
 *    https://www.compuphase.com/electronics/debouncing.htm
 *
 * Note:
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/
   
#include <`$INSTANCE_NAME`.h> // must specify API prefix in Symbol->Properties->Doc.APIPrefix


#define `$INSTANCE_NAME`_MASK   ((`$INSTANCE_NAME`_InpWidth==32)? (~0u) : ~(~0u<<`$INSTANCE_NAME`_InpWidth))   // buttons mask 
 

//====================================
//        private variables
//====================================


//====================================
//        private functions
//====================================
//CY_ISR_PROTO(`$INSTANCE_NAME`_myPollInt);   // interrupt on external polling clock

    
 
    
//==============================================================================
// interrupt on external clock for polling states
//
//==============================================================================

CY_ISR(`$INSTANCE_NAME`_myPollInt) 
{   
    
    `$INSTANCE_NAME`_CheckStatus();  
    
}    

    
//==============================================================================
// Read pins status (using default read functions)
// returns current state: 32-bit word combining REG_3, REG_2, REG_1, REG_0 
//==============================================================================
/*
__INLINE uint32 `$INSTANCE_NAME`_ReadPins() // 
{
    uint32 result; // 

    
    #if (`$INSTANCE_NAME`_InpWidth <= 8u)    
        result  = ((uint32)`$INSTANCE_NAME`_REG_0_Read());      // 
      
    #elif (`$INSTANCE_NAME`_InpWidth <= 16u)
        result  = ((uint32)`$INSTANCE_NAME`_REG_0_Read())    |  // 
                  ((uint32)`$INSTANCE_NAME`_REG_1_Read()<<8u);  // 
          
    #elif (`$INSTANCE_NAME`_InpWidth <= 24u)
        result  = ((uint32)`$INSTANCE_NAME`_REG_0_Read())     |
                  ((uint32)`$INSTANCE_NAME`_REG_1_Read()<<8u) |  // 
                  ((uint32)`$INSTANCE_NAME`_REG_2_Read()<<16u);  // 
          
    #elif (`$INSTANCE_NAME`_InpWidth <= 32u)
        result  = ((uint32)`$INSTANCE_NAME`_REG_0_Read())     |
                  ((uint32)`$INSTANCE_NAME`_REG_1_Read()<<8u) |    
                  ((uint32)`$INSTANCE_NAME`_REG_2_Read()<<16u)|  // 
                  ((uint32)`$INSTANCE_NAME`_REG_3_Read()<<24u);  // 
          
    #endif            

    return result;
}
*/

//==============================================================================
// Read pins status (fast inline code)
// returns current state: 32-bit word combining REG_3, REG_2, REG_1, REG_0 
//==============================================================================

__INLINE uint32 `$INSTANCE_NAME`_ReadPins() // 
{
    uint32 result; // 
    
    #if (`$INSTANCE_NAME`_InpWidth <= 8u)    
        result  = ((uint32)((`$INSTANCE_NAME`_REG_0_PS & `$INSTANCE_NAME`_REG_0_MASK) >> `$INSTANCE_NAME`_REG_0_SHIFT));       
      
    #elif (`$INSTANCE_NAME`_InpWidth <= 16u)
        result  = ((uint32)((`$INSTANCE_NAME`_REG_0_PS & `$INSTANCE_NAME`_REG_0_MASK) >> `$INSTANCE_NAME`_REG_0_SHIFT))    |   
                  ((uint32)((`$INSTANCE_NAME`_REG_1_PS & `$INSTANCE_NAME`_REG_1_MASK) >> `$INSTANCE_NAME`_REG_1_SHIFT)<<8u);   
          
    #elif (`$INSTANCE_NAME`_InpWidth <= 24u)
        result  = ((uint32)((`$INSTANCE_NAME`_REG_0_PS & `$INSTANCE_NAME`_REG_0_MASK) >> `$INSTANCE_NAME`_REG_0_SHIFT))     |
                  ((uint32)((`$INSTANCE_NAME`_REG_1_PS & `$INSTANCE_NAME`_REG_1_MASK) >> `$INSTANCE_NAME`_REG_1_SHIFT)<<8u) |    
                  ((uint32)((`$INSTANCE_NAME`_REG_2_PS & `$INSTANCE_NAME`_REG_2_MASK) >> `$INSTANCE_NAME`_REG_2_SHIFT)<<16u);   
          
    #elif (`$INSTANCE_NAME`_InpWidth <= 32u)
        result  = ((uint32)((`$INSTANCE_NAME`_REG_0_PS & `$INSTANCE_NAME`_REG_0_MASK) >> `$INSTANCE_NAME`_REG_0_SHIFT))     |
                  ((uint32)((`$INSTANCE_NAME`_REG_1_PS & `$INSTANCE_NAME`_REG_1_MASK) >> `$INSTANCE_NAME`_REG_1_SHIFT)<<8u) |      
                  ((uint32)((`$INSTANCE_NAME`_REG_2_PS & `$INSTANCE_NAME`_REG_2_MASK) >> `$INSTANCE_NAME`_REG_2_SHIFT)<<16u)|    
                  ((uint32)((`$INSTANCE_NAME`_REG_3_PS & `$INSTANCE_NAME`_REG_3_MASK) >> `$INSTANCE_NAME`_REG_3_SHIFT)<<24u);   
          
    #endif            

    return result;
}


//==============================================================================
// Checks pins status using vertical counters algorithm
// and sets event flags: pressed and released 
//==============================================================================

__INLINE void `$INSTANCE_NAME`_CheckStatus() // 
{
           uint32 sample;           // pins sample
           uint32 delta;            // sample change
           uint32 toggle;           // toggled pins
    static uint32 cnt0, cnt1;       // counters
    static uint32 state;            // current pins state (1-pressed, 0-released)

    
    sample = `$INSTANCE_NAME`_ReadPins();
    sample  = ~sample & `$INSTANCE_NAME`_MASK; // 
    

    // code returns the state and transition->
    delta = sample ^ state;
    cnt1 = (cnt1 ^ cnt0) & delta;
    cnt0 = ~cnt0 & delta;

    toggle = delta & ~(cnt0 | cnt1);
    state ^= toggle;
    
    //`$INSTANCE_NAME`_State = state;
    
    #if (`$INSTANCE_NAME`_Events & BTN_PRESSED)
        uint32 fBtnPressed = toggle & state;              // on rising edge
        `$INSTANCE_NAME`_Pressed |= fBtnPressed;    // latch pressed 
    #endif
        
    #if (`$INSTANCE_NAME`_Events & BTN_RELEASED)
        uint32 fBtnReleased = toggle & ~state;             // on falling edge
        `$INSTANCE_NAME`_Released |= fBtnReleased;  // latch pressed  //+9 ticks
    #endif    
}


//==============================================================================
// Initialize encoder 
//==============================================================================

void `$INSTANCE_NAME`_Start()
{ 
    #if `$INSTANCE_NAME`_IsrInternal
        `$INSTANCE_NAME`_isrPoll_StartEx(`$INSTANCE_NAME`_myPollInt);//start isrPoll interrupt
    #endif    
} 

//==============================================================================
// Stop encoder 
//==============================================================================

void `$INSTANCE_NAME`_Stop()
{    
    #if `$INSTANCE_NAME`_IsrInternal
        `$INSTANCE_NAME`_isrPoll_Stop();    //stop isrPoll interrupt
    #endif    
} 



/* [] END OF FILE */
