This Cypress Creator library component was developed as part of PSoC
study and does not pursue any particular purpose. It is free to use,
distribute or modify, all at your own risk.

Component:
   ButtonSw32: Implements button switch debouncer
   Version (v0.0)

Component Library location:
   .\ButtonSw32\ButtonSw32_lib.cylib

Description:
   Implements vertical counters algorithm for switch debouncing.
   Detects button pressed and released events.
   Does not consume hardware resources. 
   Debounces up to 32 buttons. 

Note:
   Based on vertical counters algorithm
   https://www.compuphase.com/electronics/debouncing.htm

Last Compiled with:
   Creator 4.0 SP1
   (to be compatible with older and newer Creator versions)

The datasheet and several basic demo projecs provided alongside the
component library.

Installation:
   For express installation unzip ButtonSw32_lib.zip and Demos.zip
   in the same folder using Windows menu option "Extract here". The resulting
   folder structure should look like this:

   .\YourFolderName
         \ButtonSw32_lib
              \ButtonSw32_lib.cylib
         \ButtonSw32_Demos
              \Demos
                   \ButtonSw_basic.cydsn
                   \ButtonSw_long press_1c.cydsn
                   \ButtonSw_2x.cydsn
                   \ButtonSw_2x_ext.cydsn
                   \ButtonSw_P4_basic.cydsn
                   \ButtonSw_P4_pin_clock.cydsn
                   \ButtonSw_P4_WDT.cydsn
                   \ButtonSw_P4_WDT_callback.cydsn
                   \ButtonSw_P4_CharLCD_1c.cydsn
                   \ButtonSw_P4_CharLCD_ex_1d.cydsn
              \Support lib
                   \KIT-042_lib
                   \KIT-059_lib

  
