/* ========================================
 *
 *
 * ========================================
*/


#include <cytypes.h>



int32 clear_sample; // clean signal  


// Select input data shape->

//#define GetSample Random100   // Random 100% density
//#define GetSample Random25    // Random 25% density
//#define GetSample Triangle    // Triangle centered at "0"
//#define GetSample Sawtooth    // sawtoothe with 
//#define GetSample PWM1        // PWM with cosine spikes on fronts
#define GetSample PWM2        // PWM with sine spikes on fronts
//#define GetSample PWM3        // PWM with 25% random noise
//#define GetSample PWM4        // PWM with random inversion
//#define GetSample Sine1       // Sine with 25% sparce random spikes
//#define GetSample Sine2       // Sine with 25% sparce random spikes



//===========================================
// Function prototypes
//===========================================
int32 Random100();
int32 Random25();
int32 Triangle();
int32 Sawtooth(); 
int32 PWM1(); 
int32 PWM2(); 
int32 PWM3(); 
int32 PWM4(); 
int32 Sine1(); 



/* [] END OF FILE */
