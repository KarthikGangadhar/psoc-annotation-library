/* ============================================================================
 * Project Name: Median_P4_basic_01a
 *
 * Description:
 *   PSoC4 Median Filter demo project. Uses MedianFilter component
 *   to filter various waveforms (triangle, ramp, sine, PWM) from noise artidacts.  
 *   Test data samples are generated on WDT0 timer and added to the Filter.
 *   The Filter output is streamed along with original data samples to the
 *   plotting software (SerialPlot) using USB-UART bridge, built into the KitProg.
 *
 *   By default the Filter input data is a square wave with large transition spikes.
 *   The Filter effectively rejects the spikes and recovers the square wave.
 *
 * Credits:
 *   Phil Ekstrom median filtering algorithm:
 *   https://www.embedded.com/better-than-average/
 *   https://embeddedgurus.com/stack-overflow/2010/10/median-filtering/  (code borrowed from here)
 *
 * Uses:
 *   Serial PLOT v0.10.0
 *   by Yavuz Ozderya
 *   https://hasanyavuz.ozderya.net/?p=244
 *   https://bitbucket.org/hyOzd/serialplot   

 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/



#include <project.h>
#include <DataSource.h>

#define BlinkLED(); {Pin_BLU_Write(0); CyDelayUs(30); Pin_BLU_Write(1);} // blink LED indicator
 


//============================================
// The interrupt handler for WDT counter 0 interrupts. 
//============================================
static volatile CYBIT isrReport_flag = 0; // semaphore flag 
void wdtInterruptCallback()
{
    // see cyapicallback.h for callback definition
    // no need to clear interrupt (done automatically)
    isrReport_flag = 1;
}


//===========================================
// Global variables
//===========================================
int16 sample, median = 0;


   
//===========================================
// Function prototypes
//===========================================
//int32 GetSample(); 


void Initialize()
{   
    CyGlobalIntEnable;              //enable global interrupts.
     
    UART_1_Start();                 //hardware UART (Transmit only)
    CyDelay(200);

    // no need to enable WDT0 timer (done automatically)
    CySysWdtSetInterruptCallback(CY_SYS_WDT_COUNTER0, wdtInterruptCallback); // WDT timer standard callback
}


int main()
{
   
    Initialize();  
    
    for(;;) //forever
    {
        
        if(isrReport_flag != 0)                     // monitor for Report Timer interrupt
        {
            isrReport_flag = 0;
            BlinkLED();                             // debug..

            sample = GetSample();                   // generate sample data (sine, ramp, etc. + noise)
            median = Filter_1_AddValue(sample);     // add sample value to filter

            Chart_1_Plot(clear_sample+200, sample, sample, median-400);  // plot data 
        }
          
    }  
    
} // main




/* [] END OF FILE */
