/* ========================================
 *
 *
 * ========================================
*/


#include <DataSource.h>
#include <stdlib.h>     // rand
#include <math.h>       // sine +add "m" to linker

static uint32 counter = 0; // free-running counter

//==============================================================================
// Random noise 100% density
//==============================================================================
int32 Random100()
{
    return  (int8) rand();  // random range int8                 
}


//==============================================================================
// Random noise 25% density
//==============================================================================
int32 Random25()
{
    uint8 Pspike = rand();                      // spike probability
    return  (Pspike > 127)? (int8) rand() : 0;  // random range int8                 
}


//==============================================================================
// Triangle centered at "0"->
//==============================================================================
int32 Triangle()
{
    counter += 1;                                   // free-running counter
    clear_sample   = abs( (int32)(counter % 256) - 128) - 64;   
    return clear_sample;
}


//==============================================================================
// positive sawtooth with 12.5% sparce random spikes ->
//==============================================================================
int32 Sawtooth()
{
    counter += 1;                               // free-running counter
    clear_sample   = (counter % 128) - 64;
    
    int16 Nampl  = (int16)rand() % 256;         // noise amplitude 256
    uint8 Pspike = (uint8)rand() < 64;          // spike probability
    int16 spike  = (Pspike)? Nampl : 0;
       
    return clear_sample + spike;                // signal + spike
}


//==============================================================================
// PWM with cosin spikes on fronts ->
//==============================================================================
int32 PWM1()
{
     // PWM ->
    counter += 1;                                   // free-running counter
    uint32 offset = (counter % 256);                // period 256
    int32 PWM  = (offset < 128)? 128 : 0;           // PWM amplitude 128, duty cycle 50%
    clear_sample = PWM;                             // signal w/o disturbance               

    // cosine spikes ->
    float cosin = cos(8 * 2*M_PI * offset/256);    // 
//    float cosin = sin(8 * 2*M_PI * offset/256);    // 
    float expnt = (offset < 128)? (exp( -((float) offset)/32.0f) ) : (-exp( -((float) (offset-128))/32.0f) ) ;
    int16 spike = 256 * expnt * cosin;              // spike amplitude 256;
//    int16 spike = 512 * expnt * cosin;              // spike amplitude 256;
                                 
    return clear_sample + spike;                    // signal + spike
}


//==============================================================================
// PWM with sine spikes on fronts ->
//==============================================================================
int32 PWM2()
{
    // PWM ->
    counter += 1;                                   // free-running counter
    uint32 offset = (counter % 256);                // period 256
    int32 PWM  = (offset < 128)? 128 : 0;           // PWM amplitude 128, duty cycle 50%
    clear_sample = PWM;                             // signal w/o disturbance               

    float sine = sin(8 * 2*M_PI * offset/256);      // sine spikes at front 
    float expnt = (offset < 128)? (exp( -((float) offset)/8.0f) ) : (-exp( -((float) (offset-128))/8.0f) ) ; // exponentially declining
//    int16 spike = 512 * expnt * sine;               // spike amplitude 256      
    int16 spike = 1024 * expnt * sine;               // spike amplitude 256      
                                     
    return clear_sample + spike;                  // signal + spike
}


//==============================================================================
// PWM with 25% density random noise ->
//==============================================================================
int32 PWM3()
{
    // PWM ->
    counter += 1;                                   // free-running counter
    uint32 offset = (counter % 256);                // period 256
    int32 PWM  = (offset < 128)? 128 : 0;           // PWM amplitude 128, duty cycle 50%
    clear_sample = PWM;                             // signal w/o disturbance               

//    int16 Nampl  = (int16)rand() % 256;             // noise amplitude 256
    int16 Nampl  = (int16)rand() % 512;             // noise amplitude 256
    uint8 Pspike = (uint8)rand() < 64;              // noise density 25%
    int16 spike  = (Pspike)? Nampl : 0;
                                        
    return clear_sample + spike;                    // signal + noise
}


//==============================================================================
// PWM with 25% random inversion ->
//==============================================================================
int32 PWM4()
{
    // PWM ->
    counter += 1;                                   // free-running counter
    uint32 offset = (counter % 256);                // period 256
    int32 PWM  = (offset < 128)? 128 : 0;           // PWM amplitude 128, duty cycle 50%
    clear_sample = PWM;                             // signal w/o disturbance               

    uint8 Pspike = (uint8)rand() < 64;              // noise density 25%
                                        
    return (Pspike)? (128-PWM) : PWM;               // PWM randomly inverted
}


//==============================================================================
// Sine with 25% sparce random spikes ->
//==============================================================================
int32 Sine1()
{
    // signal
    counter += 1;                                   // free-running counter
    int32 sine = 128 * sin(2* M_PI * counter/256);// sine amplitude 128
    clear_sample = sine;
    
    // noise
    int16 Nampl  = (int16)rand() % 512;             // noise amplitude 512
    uint8 Pspike = (uint8)rand() < 64 ;             // spike probability 25%
    int16 spike  = (Pspike)? Nampl : 0;       
                                     
    return clear_sample + spike;                    // signal + noise
}


//==============================================================================
// Sine with PWM spikes at cycle start ->
//==============================================================================
int32 Sine2()
{
    // signal
    counter += 1;                                       // free-running counter
    int32 sine = 128 * sin( 2*M_PI * counter/256);      // sine amplitude 128
    clear_sample = sine;
    
    // noise
    uint32 offset = counter % 256;                      // PWM phase        
    static int16 Nampl = 0;
    Nampl = (offset==0)? ((uint16)rand() % 512) : Nampl; // noise amplitude 512
    int32 spike  = (offset < 8)? Nampl : 0;             // PWM width 8
    
    return clear_sample + spike;                        // signal + noise
}


/* [] END OF FILE */
