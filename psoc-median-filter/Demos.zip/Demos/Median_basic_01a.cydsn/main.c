/* ============================================================================
 * Project Name: Median_basic_01a
 *
 * Description:
 *   PSoC5 Median Filter demo project. Uses MedianFilter component
 *   to filter various waveforms (triangle, rapm, sine, PWM) from noise artidacts.  
 *   Test data samples are generated on clock timer and added to the Filter.
 *   The Filter output is streamed along with original data samples to the
 *   plotting software (SerialPlot) using USB-UART bridge, built into the KitProg.
 *
 *   By default the Filter input data is a square wave with large transition spikes.
 *   The Filter effectively rejects the spikes and recovers the square wave.
 *   The FIR filter is added to the project for comparison, using PSoC5 built-in
 *   Digital Filter block.  
 *
 * Credits:
 *   Phil Ekstrom median filtering algorithm:
 *   https://www.embedded.com/better-than-average/
 *   https://embeddedgurus.com/stack-overflow/2010/10/median-filtering/  (code borrowed from here)
 *
 * Uses:
 *   Serial PLOT v0.10.0
 *   by Yavuz Ozderya
 *   https://hasanyavuz.ozderya.net/?p=244
 *   https://bitbucket.org/hyOzd/serialplot   

 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/

#include "project.h"
#include <DataSource.h>

#define BlinkLED(); {Pin_LED_Write(1); CyDelayUs(10); Pin_LED_Write(0);} // blink LED indicator


//===========================================
// ISR report (to output data via UART) 
//===========================================
static volatile CYBIT isrReport_flag = 0; // semaphore flag 
CY_ISR(IRQ_InterruptReport)
{
    isrReport_flag = 1;
}

//===========================================
// Global variables
//===========================================

//int8 sample, median, value1, value2 = 0;
int16 sample, median, value1, value2 = 0;
//int32 sample, median, value1, value2 = 0;
int32 filter_result;   
    
//===========================================
// Function prototypes
//===========================================



void Initialize()
{   
    CyGlobalIntEnable;                          // enable global interrupts.
     
    UART_1_Start();                             // hardware UART (Transmit only)
    CyDelay(200);
        
    Filter_Start();                             // Linear FIR filter

    isrReport_StartEx(IRQ_InterruptReport);     // start report timer
}


int main(void)
{

    Initialize(); 
    
    for(;;)
    {
        if(isrReport_flag != 0)                             // monitor for Report Timer interrupt
        {
            isrReport_flag = 0;
            BlinkLED();                                     // debug..

            sample = GetSample();                           // generate next data sample
            median = Filter_1_AddValue(sample);             // add asample to Median filter 
            
            Filter_Write24( Filter_CHANNEL_A, sample);      // add sample to FIR filter
            filter_result=Filter_Read24(Filter_CHANNEL_A);  // read back from FIR filter (also clears interrupt)

            Chart_1_Plot(clear_sample+200, sample, filter_result-200, median-400);  // plot data 
        }
        
    }
    
}



/* [] END OF FILE */
