This Cypress Creator library component was developed as part of PSoC
study and does not pursue any particular purpose. It is free to use,
distribute or modify, all at your own risk.

Component:
   MedianFiltert: Implements sliding window median filter
   Version (v0.0)

Component Library location:
   .\MedianFilter_lib\MedianFilter_lib.cylib

Description:
   Implements sliding window median algorithm.
   Range: int8, int16, int32, uint8, uint16, uint32. 
   Doesn�t use hardware resources.
   Has fixed execution time.
   Grows linear with size.
   Non-decimating. 


Credits:
   Phil Ekstrom median filtering algorithm:
   https://www.embedded.com/better-than-average/
   https://embeddedgurus.com/stack-overflow/2010/10/median-filtering/  (code borrowed from here)

Compiled with:
   Creator 4.0 SP1
   (to be compatible with older and newer Creator versions)

The datasheet and basic demo projecs are provided alongside the
component library.

Installation:
   For express installation unzip SerialPlot_lib.zip and Demos.zip
   in the same folder using Windows menu option "Extract here". The resulting
   folder structure should look like this:

   .\YourFolderName
         \MedianFilter_lib
              \MedianFilter_lib.cylib
         \Demos
              \MedianFilter_basic_01a.cydsn
              \MedianFilter_P4_basic_01a.cydsn
         \Support_libs
              \AnnotationLibrary_lib
                   \AnnotationLibrary_lib.cylib
              \KIT-042_lib
                   \KIT-042_lib.cylib

  
