/* ============================================================================
 * File Name: SerialPlot_P4_basic_01a
 *
 * Description:
 *   Basic xample showing use of SerialPlot component on PSoC4 for data output
 *   to real-time charting software (SerialPlot). Test data are generated 
 *   on WDT0 timer and sent to host computer for visualisation using UART.
 *
 * Credits:
 *   uses Serial PLOT v0.10.0 - freeware charting software by Yavuz Ozderya
 *   https://hasanyavuz.ozderya.net/?p=244
 *   https://bitbucket.org/hyOzd/serialplot   
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/



#include "project.h"
#include <stdlib.h> // rand
#include <math.h>   // sine

#define BlinkLED(); {Pin_BLU_Write(0); CyDelayUs(30); Pin_BLU_Write(1);} // blink LED indicator



//============================================
// The interrupt handler for WDT counter 0 interrupts. 
//============================================
static volatile CYBIT isrReport_flag = 0; // semaphore flag 
void wdtInterruptCallback()
{
    // see cyapicallback.h for callback definition
    // no need to clear interrupt (done automatically)
    isrReport_flag = 1;
}


//===========================================
// Global variables
//===========================================
//int8 value1, value2, value3, value4 = 0;
int16 value1, value2, value3, value4 = 0;
//int32 value1, value2, value3, value4 = 0;
//float32 value1, value2, value3, value4 = 0;


   
//===========================================
// Function prototypes
//===========================================
void GenerateSignal();


void Initialize()
{   
    CyGlobalIntEnable;              //enable global interrupts.
     
    UART_1_Start();                 //hardware UART (Transmit only)
    CyDelay(200);

    // generating test data on WDT timer callback
    // no need to enable WDT0 timer (done automatically)
    CySysWdtSetInterruptCallback(CY_SYS_WDT_COUNTER0, wdtInterruptCallback); // can use standard callback
}


int main()
{
   
    Initialize();  
    
    for(;;) //forever
    {
        
        if(isrReport_flag != 0)                     // monitor for Report Timer interrupt
        {
            isrReport_flag = 0;
            BlinkLED();                             // debug..

            GenerateSignal();
            Chart_1_Plot(value1, value2, value3-250, value4-350);                
        }    
        
    }  
    
} // main


//==============================================================================
// Generate test signals
//==============================================================================
void GenerateSignal()
{
    static uint8 counter = 0; // period = 256

    counter++;
    
    value1 = 127 * sin( (float32) 2*M_PI*counter/256.0 );   // sine
    value2 = 127 * cos( (float32) 2*M_PI*counter/256.0 );   // cosine
    value3 = abs(counter - 128);                            //triangle > 0
    value4 = (counter<128)? 0 : 64;                         // square wave 
}






