/* ============================================================================
 * Project Name: SerialPlot_basic_01a
 *
 * Description:
 *   PSoC5 demo showing data output and plotting using SerialPLOT charting software
 * 
 * Uses:
 *   Serial PLOT v0.10.0
 *   by Yavuz Ozderya
 *   https://bitbucket.org/hyOzd/serialplot  
 *   https://hasanyavuz.ozderya.net/?p=244
 *   https://hackaday.io/project/5334-serialplot-realtime-plotting-software/discussion-88924
 *
 * ============================================================================
 * PROVIDED AS-IS, NO WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * FREE TO SHARE, USE AND MODIFY UNDER TERMS: CREATIVE COMMONS - SHARE ALIKE
 * ============================================================================
*/

#include "project.h"
#include <stdlib.h> // rand
#include <math.h>   // sine

#define BlinkLED(); {Pin_LED_Write(1); CyDelayUs(10); Pin_LED_Write(0);} // blink LED indicator


//===========================================
// ISR report (to output data via UART) 
//===========================================
static volatile CYBIT isrReport_flag = 0; // semaphore flag 
CY_ISR(IRQ_InterruptReport)
{
    isrReport_flag = 1;
}

//===========================================
// Global variables
//===========================================

//int8 value1, value2, value3, value4, value5, value6, value7, value8 = 0;
int16 value1, value2, value3, value4, value5, value6, value7, value8 = 0;
//int32 value1, value2, value3, value4, value5, value6, value7, value8 = 0;
//float32 value1, value2, value3, value4, value5, value6, value7, value8 = 0;

    
    
//===========================================
// Function prototypes
//===========================================
void GenerateSignal();



void Initialize()
{   
    CyGlobalIntEnable;             //enable global interrupts.
     
    UART_1_Start();//hardware UART (Transmit only)
    CyDelay(200);
   
    isrReport_StartEx(IRQ_InterruptReport); 
}


int main(void)
{

    Initialize(); 
    
    for(;;)
    {
        
        if(isrReport_flag != 0)         // monitor for Report Timer interrupt
        {
            isrReport_flag = 0;
            BlinkLED();                  // debug..
            
            GenerateSignal();
            Chart_1_Plot(value1, value2, value3-250, value4-350);                
        }
        
    }
    
}



//==============================================================================
// Generate test signals
//==============================================================================
void GenerateSignal()
{
    static uint8 counter = 0; // period = 256

    counter++;
    
    // int16 (x4)  ->
    value1 = 127 * sin( (float32) 2*M_PI*counter/256.0 );   // sine
    value2 = 127 * cos( (float32) 2*M_PI*counter/256.0 );   // cosine
    //value3 = (counter==0)? -128: value3 + 1;              // sawtooth
    value3 = abs(counter - 128); //triangle > 0
    value4 = (counter<128)? 0 : 64;                   // square wave
    
}

/* [] END OF FILE */
