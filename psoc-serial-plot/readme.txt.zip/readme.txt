This Cypress Creator library component was developed as part of PSoC
study and does not pursue any particular purpose. It is free to use,
distribute or modify, all at your own risk.

Component:
   SerialPlot: Implements software interface to the SerialPlot real-time plotting software
   Version (v0.0)

Component Library location:
   .\SerialPlot\SerialPlot_lib.cylib

Description:
   Implements interface between PSoC and SerialPlot software.
   Data types: int8, int16, int32, uint8, uint16, uint32, float 
   Doesn�t use hardware resources
   Up to 8 channels. 

Credits:
   Serial PLOT v0.10.0, by Hasan Yavuz �zderya,
   https://hasanyavuz.ozderya.net/?p=244
   https://bitbucket.org/hyOzd/serialplot

Compiled with:
   Creator 4.0 SP1
   (to be compatible with older and newer Creator versions)

The datasheet and basic demo projecs are provided alongside the
component library.

Installation:
   For express installation unzip SerialPlot_lib.zip and Demos.zip
   in the same folder using Windows menu option "Extract here". The resulting
   folder structure should look like this:

   .\YourFolderName
         \SerialPlot_lib
              \SerialPlot_lib.cylib
         \Demos
              \SerialPlot_basic_01a.cydsn
              \SerialPlot_P4_basic_01a.cydsn
         \Support_libs
              \AnnotationLibrary_lib
                   \AnnotationLibrary_lib.cylib
              \KIT-042_lib
                   \KIT-042_lib.cylib

  
